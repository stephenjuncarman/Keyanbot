module.exports = {
 config: {
 name: "gerald",
 version: "1.0",
 author: "gtut",
 countDown: 5,
 role: 0,
 shortDescription: "",
 longDescription: "",
 category: "management",
 },
onStart: async function(){}, 
onChat: async function({
 event,
 message,
 getLang
}) {
 if (event.body && event.body.toLowerCase() == "gerald") return message.reply("hi, I'm gerald's chatbot, I think he's is busy now so, when he returns he will reply you, but before he comes type ?help to see a magic.");
}
};